import React from "react";
import { colors } from "../../assets/colors/indes.ts";
import { fonts } from "../../assets/fonts/index.ts";

type PlaceholderProps = {
  title: string;
};

const Placeholder: React.FC<PlaceholderProps> = ({ title }) => {
  return (
    <main
      style={{
        padding: "2rem",
        fontFamily: fonts.regular,
        color: colors.green,
        minHeight: "50vh",
      }}
    >
      <h1>{title}</h1>
      <p>Coming soon.</p>
    </main>
  );
};

export default Placeholder;
