import React from "react";
import { useParams, Navigate } from "react-router-dom";
import { getTrailerById, getTrailerTypeLabel } from "../../../assets/data/trailers.ts";
import {
  TrailerTitleSection,
  TrailerImageGallery,
  RatingSummaryCard,
  FeatureIconsSection,
  StickyPricingCard,
  GuestFavouriteSection,
  ReviewsSection,
  PolicySection,
} from "../../../components/TrailerDetails/index.ts";

const Trailer: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const trailer = id ? getTrailerById(Number(id)) : undefined;

  if (!trailer) {
    return <Navigate to="/" replace />;
  }

  const typeLabel = getTrailerTypeLabel(trailer.type);
  const locationText = `${typeLabel} – ${trailer.location}`;

  return (
    <div className="min-h-screen  bg-background">
      <div className="max-w-container mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
        <TrailerTitleSection
          title={trailer.title}
          location={locationText}
          specs={trailer.specs}
        />

        <TrailerImageGallery images={trailer.images} />

        <div className="mb-6">
          <p className="text-lg font-medium text-gray-900">
            {locationText}
          </p>
          <p className="text-sm text-gray-600">
            {trailer.specs}
          </p>
        </div>

        <div className="lg:grid lg:grid-cols-3 lg:gap-10">
          <div className="lg:col-span-2 space-y-16">
            <RatingSummaryCard
              rating={trailer.rating}
              description={trailer.ratingDescription}
              reviewCount={trailer.reviewCount}
            />

            <FeatureIconsSection features={trailer.features} />

            <GuestFavouriteSection
              rating={trailer.guestFavouriteRating}
              title="Guest Favourite"
              description={trailer.guestFavouriteDescription}
              metrics={trailer.metrics}
            />

            <ReviewsSection reviews={trailer.reviews} />

            <PolicySection />
          </div>

          <div className="lg:col-span-1 mt-8 lg:mt-0">
            <StickyPricingCard price={trailer.price} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Trailer;