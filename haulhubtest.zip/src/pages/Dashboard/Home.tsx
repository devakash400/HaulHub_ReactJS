import React from "react";
import Container from "./Container.tsx";
import { colors } from "../../assets/colors/indes.ts";
import { CategorySection } from "../../components/CategorySection.tsx";
import { getGooseneckListItems, getBumperPullListItems } from "../../assets/data/trailers.ts";

const Home: React.FC = () => {
  const gooseneckItems = getGooseneckListItems();
  const bumperPullItems = getBumperPullListItems();

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: colors.white,
      }}
    >
      <Container />

      <CategorySection title="Gooseneck trailers" items={gooseneckItems} />

      <CategorySection title="Bumper pull trailers" items={bumperPullItems} />
    </div>
  );
};

export default Home;