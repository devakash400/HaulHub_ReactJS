import React from "react";
import { images } from "../../assets/images/index.ts";
import { colors } from "../../assets/colors/indes.ts";
import { fonts } from "../../assets/fonts/index.ts";


const Container: React.FC = () => {
  return (
    <main
      style={{
        width: "100%",
        margin: "0",
        padding: "0",
        fontFamily: fonts.regular,
      }}
    >
      {/* Hero with background image and search bar */}
      <section
        style={{
          position: "relative",
          width: "100%",
          borderRadius: 0,
          overflow: "hidden",
          boxShadow: "none",
          marginBottom: "0",
        }}
      >
        <img
          src={images.Container}
          alt="HaulHub trailer hero"
          style={{
            width: "100%",
            height: "560px",
            objectFit: "cover",
            display: "block",
          }}
        />

        {/* Search bar overlay */}
        <div
          style={{
            position: "absolute",
            left: "50%",
            top: "50%",
            transform: "translate(-50%, -50%)",
            width: "min(90%, 720px)",
            backgroundColor: "#ffffff",
            height: "70px",
            borderRadius: "30px",
            boxShadow: "0 18px 35px rgba(15, 23, 42, 0.25)",
            display: "flex",
            alignItems: "center",
            padding: "0 0.75rem",
            gap: "0.75rem",
          }}
        >
          {/* Text search input */}
          <input
            type="text"
            placeholder="Search"
            style={{
              flex: 1,
              height: "100%",
              border: "none",
              outline: "none",
              backgroundColor: "transparent",
              fontSize: "0.95rem",
              color: colors.green,
              fontFamily: fonts.regular,
              padding: "0 0.75rem",
            }}
          />

          {/* Search button */}
          <button
            type="button"
            style={{
              flexShrink: 0,
              width: "56px",
              height: "56px",
              borderRadius: "50%",
              border: "none",
              backgroundColor: "#16a34a",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              marginLeft: "0.25rem",
              boxShadow: "0 14px 30px rgba(22, 163, 74, 0.6)",
            }}
          >
            <span
              style={{
                width: "18px",
                height: "18px",
                borderRadius: "9999px",
                border: "2px solid #ffffff",
                position: "relative",
              }}
            >
              <span
                style={{
                  position: "absolute",
                  right: "-6px",
                  bottom: "-2px",
                  width: "10px",
                  height: "2px",
                  borderRadius: "9999px",
                  backgroundColor: "#ffffff",
                  transform: "rotate(45deg)",
                  transformOrigin: "right center",
                }}
              />
            </span>
          </button>
        </div>
      </section>


    </main>
  );
};

export default Container;
