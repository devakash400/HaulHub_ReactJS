import React from "react";
import { colors } from "../../assets/colors/indes.ts";
import { fonts } from "../../assets/fonts/index.ts";

const About: React.FC = () => {
  return (
    <main
      style={{
        padding: "2rem",
        fontFamily: fonts.regular,
        color: colors.green,
        minHeight: "50vh",
      }}
    >
      <h1>About HaulHub</h1>
      <p>Learn more about our trailer rental platform.</p>
    </main>
  );
};

export default About;
