import React from "react";
import { colors } from "../../assets/colors/indes.ts";
import { fonts } from "../../assets/fonts/index.ts";

const ListTrailer: React.FC = () => {
  return (
    <main
      style={{
        padding: "2rem",
        fontFamily: fonts.regular,
        color: colors.green,
        minHeight: "50vh",
      }}
    >
      <h1>List Your Trailer</h1>
      <p>Add your trailer to the HaulHub marketplace.</p>
    </main>
  );
};

export default ListTrailer;
