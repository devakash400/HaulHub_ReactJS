import type { CSSProperties } from "react";
import { colors } from "../../../assets/colors/indes.ts";
import { fonts } from "../../../assets/fonts/index.ts";


export const overlayStyle: CSSProperties = {
  position: "fixed",
  inset: 0,
  backgroundColor: "rgba(0,0,0,0.45)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 40,
};

export const modalStyle: CSSProperties = {
  width: "100%",
  maxWidth: "420px",
  backgroundColor: colors.white,
  borderRadius: "18px",
  padding: "1.75rem 1.75rem 1.5rem",
  boxShadow: "0 20px 40px rgba(15, 23, 42, 0.25)",
  fontFamily: fonts.regular,
  position: "relative",
};

export const headerRowStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  marginBottom: "1.25rem",
  paddingBottom: "0.75rem",
  borderBottom: "1px solid #E5E7EB",
  position: "relative",
  width: "100%",
};

export const titleStyle: CSSProperties = {
  margin: 0,
  fontSize: "1.25rem",
  fontFamily: fonts.semiBold,
  color: colors.black,
};

export const closeButtonStyle: CSSProperties = {
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 0,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  position: "absolute",
  left: 0,
};

export const closeIconStyle: CSSProperties = {
  width: "20px",
  height: "20px",
  objectFit: "contain",
};

export const labelStyle: CSSProperties = {
  display: "block",
  fontSize: "0.85rem",
  marginBottom: "0.4rem",
  color: colors.black,
  fontFamily: fonts.medium,
};

export const requiredMarkStyle: CSSProperties = {
  color: "#EF4444",
  marginLeft: "2px",
};

export const inputStyle: CSSProperties = {
  width: "90%",
  margin: "0 auto",
  padding: "0.6rem 0.8rem",
  borderRadius: "5px",
  border: `1px solid ${colors.gray}`,
  fontSize: "0.9rem",
  fontFamily: fonts.regular,
  outline: "none",
};

export const helperTextStyle: CSSProperties = {
  fontSize: "0.7rem",
  color: colors.gray,
  marginTop: "0.35rem",
};

export const continueButtonBaseStyle: CSSProperties = {
  width: "100%",
  marginTop: "1rem",
  padding: "0.65rem 1rem",
  borderRadius: "999px",
  border: "none",
  fontSize: "0.95rem",
  fontFamily: fonts.medium,
  cursor: "pointer",
  transition: "background-color 0.15s ease, opacity 0.15s ease",
};

export const continueButtonDisabledStyle: CSSProperties = {
  ...continueButtonBaseStyle,
  backgroundColor: "#E5E7EB",
  color: colors.gray,
  cursor: "not-allowed",
};

export const continueButtonActiveStyle: CSSProperties = {
  ...continueButtonBaseStyle,
  backgroundColor: colors.green,
  color: colors.white,
};

export const dividerRowStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "0.75rem",
  margin: "1.25rem 0 1rem",
  fontSize: "0.8rem",
  color: colors.gray,
};

export const dividerLineStyle: CSSProperties = {
  flex: 1,
  height: "1px",
  backgroundColor: "#E5E7EB",
};

export const dividerTextStyle: CSSProperties = {
  whiteSpace: "nowrap",
  fontFamily: fonts.regular,
};

export const providerButtonStyle: CSSProperties = {
  width: "100%",
  padding: "0.65rem 1rem",
  borderRadius: "5px",
  border: "1px solid #E5E7EB",
  backgroundColor: colors.white,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "0.5rem",
  fontSize: "0.9rem",
  fontFamily: fonts.regular,
  cursor: "pointer",
  marginBottom: "0.5rem",
};

export const providerIconStyle: CSSProperties = {
  width: "18px",
  height: "18px",
  objectFit: "contain",
};

export const providerTextStyle: CSSProperties = {
  fontFamily: fonts.regular,
};

