import React, { useState, MouseEvent } from "react";

import {
  overlayStyle,
  modalStyle,
  headerRowStyle,
  titleStyle,
  closeButtonStyle,
  closeIconStyle,
  labelStyle,
  requiredMarkStyle,
  inputStyle,
  helperTextStyle,
  continueButtonDisabledStyle,
  continueButtonActiveStyle,
  dividerRowStyle,
  dividerLineStyle,
  dividerTextStyle,
  providerButtonStyle,
  providerIconStyle,
  providerTextStyle,
} from "./Login.styles.ts";
import { images } from "../../../assets/images/index.ts";

type LoginModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState("");

  if (!isOpen) return null;

  const isEmailFilled = email.trim().length > 0;

  const handleOverlayClick = () => {
    onClose();
  };

  const handleModalClick = (event: MouseEvent<HTMLDivElement>) => {
    event.stopPropagation();
  };

  return (
    <div style={overlayStyle} onClick={handleOverlayClick}>
      <div style={modalStyle} onClick={handleModalClick}>
        <div style={headerRowStyle}>
          <h2 style={titleStyle}>Login</h2>
          <button
            type="button"
            style={closeButtonStyle}
            onClick={onClose}
            aria-label="Close login"
          >
            <img src={images.Cross} alt="Close" style={closeIconStyle} />
          </button>
        </div>

        <div>
          <label style={labelStyle} htmlFor="login-email">
            Email ID <span style={requiredMarkStyle}>*</span>
          </label>
          <input
            id="login-email"
            type="email"
            placeholder="Enter your Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={inputStyle}
          />
          <p style={helperTextStyle}>We&apos;ll send a verification link.</p>

          <button
            type="button"
            disabled={!isEmailFilled}
            style={
              isEmailFilled
                ? continueButtonActiveStyle
                : continueButtonDisabledStyle
            }
          >
            Continue
          </button>
        </div>

        <div style={dividerRowStyle}>
          <div style={dividerLineStyle} />
          <span style={dividerTextStyle}>Or</span>
          <div style={dividerLineStyle} />
        </div>

        <button type="button" style={providerButtonStyle}>
          <img
            src={images.Phone}
            alt="Phone"
            style={providerIconStyle}
          />
          <span style={providerTextStyle}>Login with Phone Number</span>
        </button>

        <button type="button" style={providerButtonStyle}>
          <img
            src={images.Google}
            alt="Google"
            style={providerIconStyle}
          />
          <span style={providerTextStyle}>Sign up with Google</span>
        </button>

        <button type="button" style={providerButtonStyle}>
          <img
            src={images.Apple}
            alt="Apple"
            style={providerIconStyle}
          />
          <span style={providerTextStyle}>Sign up with Apple</span>
        </button>
      </div>
    </div>
  );
};

export default LoginModal;

