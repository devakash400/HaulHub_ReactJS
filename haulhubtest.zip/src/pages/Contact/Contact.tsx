import React from "react";
import { colors } from "../../assets/colors/indes.ts";
import { fonts } from "../../assets/fonts/index.ts";

const Contact: React.FC = () => {
  return (
    <main
      style={{
        padding: "2rem",
        fontFamily: fonts.regular,
        color: colors.green,
        minHeight: "50vh",
      }}
    >
      <h1>Contact Us</h1>
      <p>Get in touch with the HaulHub team.</p>
    </main>
  );
};

export default Contact;
