

// Images
import logo from './appLogo.png';
import appStore from './appStore.png';
import googlePlay from './googlePlay.png';
import Catimg from './CatImg.png';
import Container from './container.png';
import Wishlist from './wishlist.png';
import ArrowRight from './arrowup.png';
import Google from './google.png';
import Phone from './phone.png';
import Apple from './apple.png';
import Cross from './cross.png'

// Export them all
export const images = {
  logo,
  appStore,
  googlePlay,
  Catimg,
  Container,
  Wishlist,
  ArrowRight,
  Google,
  Phone,
  Apple,
  Cross
};