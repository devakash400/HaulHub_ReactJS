import type { CSSProperties } from "react";
import { colors } from "../../assets/colors/indes.ts";
import { fonts } from "../../assets/fonts/index.ts";

export const navStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  padding: "0.75rem 1.5rem",
  backgroundColor: colors.background,
  borderBottom: "1px solid #e5e7eb",
  position: "sticky",
  top: 0,
  zIndex: 20,
  fontFamily: fonts.regular,
};

export const logoStyle: CSSProperties = {
  height: "50px",
  objectFit: "contain",
};

export const rightSectionStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "1.25rem",
  color: colors.black,
  fontSize: "0.95rem",
  position: "relative",
};

export const listTrailerTextStyle: CSSProperties = {
  fontFamily: fonts.regular,
  fontSize: "15px",
};

export const drawerToggleButtonStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "0.35rem 0.75rem",
  borderRadius: "9999px",
  border: "none",
  backgroundColor: colors.background,
  cursor: "pointer",
};

export const drawerIconContainerStyle: CSSProperties = {
  display: "inline-flex",
  flexDirection: "column",
  gap: "3px",
};

export const drawerIconBarStyle: CSSProperties = {
  width: "16px",
  height: "2px",
  borderRadius: "9999px",
  backgroundColor: colors.black,
};

// Dropdown that appears under the navbar button
export const drawerContainerStyle: CSSProperties = {
  position: "absolute",
  top: "2.75rem",
  right: 0,
  backgroundColor: colors.white,
  borderRadius: "0.5rem",
  boxShadow: "0 10px 25px rgba(15, 23, 42, 0.15)",
  padding: "0.5rem 0",
  minWidth: "180px",
  zIndex: 30,
};

export const drawerHeaderStyle: CSSProperties = {
  display: "none",
};

export const drawerBodyStyle: CSSProperties = {
  padding: 0,
};

export const drawerBodyListStyle: CSSProperties = {
  listStyle: "none",
  margin: 0,
  padding: 0,
  fontFamily: fonts.regular,
  fontSize: "0.9rem",
  color: colors.black,
};

export const drawerBodyListItemStyle: CSSProperties = {
  padding: "0.4rem 1.25rem",
  cursor: "pointer",
  whiteSpace: "nowrap",
};

