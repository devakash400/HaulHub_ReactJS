import React, { useState } from "react";
import { Link } from "react-router-dom";
import { images } from "../../assets/images/index.ts";
import {
  navStyle,
  logoStyle,
  rightSectionStyle,
  listTrailerTextStyle,
  drawerToggleButtonStyle,
  drawerIconContainerStyle,
  drawerIconBarStyle,
  drawerContainerStyle,
  drawerBodyStyle,
  drawerBodyListStyle,
  drawerBodyListItemStyle,
} from "./styles.ts";

const linkStyle: React.CSSProperties = {
  color: "inherit",
  textDecoration: "none",
  cursor: "pointer",
};

const Navbar: React.FC = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const toggleDrawer = () => setIsDrawerOpen((prev) => !prev);
  const closeDrawer = () => setIsDrawerOpen(false);

  return (
    <nav style={navStyle}>
      {/* Left: Logo */}
      <Link to="/" style={linkStyle} onClick={closeDrawer}>
        <img
          src={images.logo}
          alt="HaulHub logo"
          style={logoStyle}
        />
      </Link>

      {/* Right: List Your Trailer + dropdown toggle */}
      <div style={rightSectionStyle}>
        <Link to="/list-trailer" style={{ ...linkStyle, ...listTrailerTextStyle }}>
          List Your Trailer
        </Link>
        <button
          type="button"
          onClick={toggleDrawer}
          style={drawerToggleButtonStyle}
          aria-label="Toggle navigation dropdown"
        >
          <span style={drawerIconContainerStyle}>
            <span style={drawerIconBarStyle} />
            <span style={drawerIconBarStyle} />
            <span style={drawerIconBarStyle} />
          </span>
        </button>

        {/* Dropdown menu */}
        {isDrawerOpen && (
          <div style={drawerContainerStyle}>
            <div style={drawerBodyStyle}>
              <ul style={drawerBodyListStyle}>
                <li style={drawerBodyListItemStyle} onClick={closeDrawer}>
                  <Link to="/" style={linkStyle}>
                    Home
                  </Link>
                </li>
                <li style={drawerBodyListItemStyle} onClick={closeDrawer}>
                  <Link to="/list-trailer" style={linkStyle}>
                    List Your Trailer
                  </Link>
                </li>
                <li style={drawerBodyListItemStyle} onClick={closeDrawer}>
                  <Link to="/about" style={linkStyle}>
                    About
                  </Link>
                </li>
                <li style={drawerBodyListItemStyle} onClick={closeDrawer}>
                  <Link to="/contact" style={linkStyle}>
                    Contact
                  </Link>
                </li>
                <li style={drawerBodyListItemStyle} onClick={closeDrawer}>
                  <Link to="/login" style={linkStyle}>
                    Login / Signup
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;

