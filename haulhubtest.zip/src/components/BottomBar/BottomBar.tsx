import React from "react";
import { Link } from "react-router-dom";
import { images } from "../../assets/images/index.ts";
import {
  footerStyle,
  footerInnerStyle,
  columnsWrapperStyle,
  columnTitleStyle,
  linkListStyle,
  linkStyle,
  rightSectionStyle,
  logoStyle,
  storeButtonsRowStyle,
  storeButtonStyle,
  storeButtonIconStyle,
  storeButtonTextWrapperStyle,
  storeButtonLabelSmallStyle,
  storeButtonLabelLargeStyle,
} from "./BottomBar.styles.ts";

const BottomBar: React.FC = () => {
  return (
    <footer style={footerStyle}>
      <div style={footerInnerStyle}>
        {/* Left side: Explore & Company columns */}
        <div style={columnsWrapperStyle}>
          <div>
            <h3 style={columnTitleStyle}>
              Explore
            </h3>
            <ul style={linkListStyle}>
              <li>
                <Link to="/why-choose" style={linkStyle}>
                  Why Choose HaulHub
                </Link>
              </li>
              <li>
                <Link to="/list-trailer" style={linkStyle}>
                  List Trailer
                </Link>
              </li>
              <li>
                <Link to="/trust-safety" style={linkStyle}>
                  Trust & Safety
                </Link>
              </li>
              <li>
                <Link to="/get-help" style={linkStyle}>
                  Get Help
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 style={columnTitleStyle}>
              Company
            </h3>
            <ul style={linkListStyle}>
              <li>
                <Link to="/list-trailer" style={linkStyle}>
                  List Trailer
                </Link>
              </li>
              <li>
                <Link to="/how-it-works" style={linkStyle}>
                  How it works
                </Link>
              </li>
              <li>
                <Link to="/about" style={linkStyle}>
                  About US
                </Link>
              </li>
              <li>
                <Link to="/contact" style={linkStyle}>
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Right side: Logo above row of store buttons */}
        <div style={rightSectionStyle}>
          <img
            src={images.logo}
            alt="HaulHub app logo"
            style={logoStyle}
          />

          <div style={storeButtonsRowStyle}>
            <a
              href="https://www.apple.com/app-store/"
              target="_blank"
              rel="noopener noreferrer"
              style={storeButtonStyle}
            >
              <img
                src={images.appStore}
                alt="App Store"
                style={storeButtonIconStyle}
              />
              <span
                style={storeButtonTextWrapperStyle}
              >
                <span
                  style={storeButtonLabelSmallStyle}
                >
                  Download on the
                </span>
                <span
                  style={storeButtonLabelLargeStyle}
                >
                  App Store
                </span>
              </span>
            </a>

            <a
              href="https://play.google.com/store"
              target="_blank"
              rel="noopener noreferrer"
              style={storeButtonStyle}
            >
              <img
                src={images.googlePlay}
                alt="Google Play"
                style={storeButtonIconStyle}
              />
              <span
                style={storeButtonTextWrapperStyle}
              >
                <span
                  style={storeButtonLabelSmallStyle}
                >
                  Get it on
                </span>
                <span
                  style={storeButtonLabelLargeStyle}
                >
                  Google Play
                </span>
              </span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default BottomBar;
