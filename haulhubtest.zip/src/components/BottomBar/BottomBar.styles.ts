import type { CSSProperties } from "react";
import { colors } from "../../assets/colors/indes.ts";
import { fonts } from "../../assets/fonts/index.ts";

export const footerStyle: CSSProperties = {
  backgroundColor: colors.background,
  borderTop: "1px solid #e5e7eb",
  padding: "2rem 1.5rem",
  fontFamily: fonts.regular,
};

export const footerInnerStyle: CSSProperties = {
  maxWidth: "1120px",
  margin: "0 auto",
  display: "flex",
  flexWrap: "wrap",
  alignItems: "flex-start",
  justifyContent: "space-between",
  gap: "2rem",
};

export const columnsWrapperStyle: CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "3rem",
  flex: 1,
  minWidth: "260px",
};

export const columnTitleStyle: CSSProperties = {
  margin: 0,
  marginBottom: "0.75rem",
  fontSize: "0.95rem",
  fontFamily: fonts.medium,
  letterSpacing: "0.03em",
  textTransform: "uppercase",
  color: "#111827",
};

export const linkListStyle: CSSProperties = {
  listStyle: "none",
  padding: 0,
  margin: 0,
  display: "flex",
  flexDirection: "column",
  gap: "0.4rem",
  fontSize: "0.9rem",
  color: colors.black,
};

export const linkStyle: CSSProperties = {
  textDecoration: "none",
  color: colors.black,
  fontFamily: fonts.regular,
  fontSize: "0.9rem",
};

export const rightSectionStyle: CSSProperties = {
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  gap: "0.75rem",
  minWidth: "260px",
  flexShrink: 0,
};

export const logoStyle: CSSProperties = {
  height: "52px",
  objectFit: "contain",
};

export const storeButtonsRowStyle: CSSProperties = {
  display: "flex",
  flexDirection: "row",
  gap: "0.75rem",
  marginTop: "0.25rem",
  justifyContent: "center",
  flexWrap: "wrap",
};

export const storeButtonStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "0.6rem",
  padding: "0.1rem 0.2rem",
  borderRadius: "2px",
  backgroundColor: colors.black,
  color: "#f9fafb",
  textDecoration: "none",
  width: "160px",
  height: "55px",
};

export const storeButtonIconStyle: CSSProperties = {
  height: "32px",
  width: "32px",
  objectFit: "contain",
};

export const storeButtonTextWrapperStyle: CSSProperties = {
  display: "flex",
  flexDirection: "column",
  lineHeight: 1.1,
  fontFamily: fonts.regular,
};

export const storeButtonLabelSmallStyle: CSSProperties = {
  fontSize: "8px",
  fontFamily: fonts.regular,
};

export const storeButtonLabelLargeStyle: CSSProperties = {
  fontSize: "1rem",
  fontFamily: fonts.regular,
};

