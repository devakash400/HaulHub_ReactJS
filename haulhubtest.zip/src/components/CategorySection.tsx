import React, { useRef, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { colors } from "../assets/colors/indes.ts";
import { fonts } from "../assets/fonts/index.ts";
import { images } from "../assets/images/index.ts";

type CategoryItem = {
  id: string | number;
  image: string;
  modelLabel: string;
  priceLabel: string;
  badgeLabel?: string;
};

type CategorySectionProps = {
  title: string;
  items: CategoryItem[];
};

export const CategorySection: React.FC<CategorySectionProps> = ({
  title,
  items,
}) => {
  const navigate = useNavigate();
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const [cardsPerRow, setCardsPerRow] = useState(1);
  const [wishlistIds, setWishlistIds] = useState<Set<string | number>>(
    () => new Set()
  );

  useEffect(() => {
    const updateCardsPerRow = () => {
      const width = window.innerWidth;

      if (width >= 1200) {
        setCardsPerRow(4); // PC
      } else if (width >= 768) {
        setCardsPerRow(3); // Tablet
      } else {
        setCardsPerRow(1); // Phone (auto)
      }
    };

    updateCardsPerRow();
    window.addEventListener("resize", updateCardsPerRow);

    return () => {
      window.removeEventListener("resize", updateCardsPerRow);
    };
  }, []);

  const cardWidth = 255;
  const gap = 32; // 2rem
  const sectionContentWidth =
    cardsPerRow * cardWidth + (cardsPerRow - 1) * gap;

  const toggleWishlist = (id: string | number) => {
    setWishlistIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleScroll = (direction: "left" | "right") => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const cardWidth = container.firstElementChild
      ? (container.firstElementChild as HTMLElement).offsetWidth + 32
      : 282; // 250 card + ~32 gap (2rem)
    const scrollAmount = cardWidth; // slide by exactly one card

    container.scrollTo({
      left:
        direction === "left"
          ? container.scrollLeft - scrollAmount
          : container.scrollLeft + scrollAmount,
      behavior: "smooth",
    });
  };

  return (
    <section
      style={{
        width: "100%",
        paddingTop: "1.5rem",
        boxSizing: "border-box",
        backgroundColor: colors.white,
        alignSelf: "center",
      }}
    >
      <div
        style={{
          maxWidth: "100%",
          margin: "0 auto",
          padding: "0 1rem",
          boxSizing: "border-box",
        }}
      >
        <div
          style={{
            maxWidth: `${sectionContentWidth}px`,
            margin: "0 auto",
          }}
        >
          <header
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: "1rem",
            }}
          >
            <h2
              style={{
                margin: 0,
                fontFamily: fonts.semiBold,
                fontSize: "1.15rem",
                color: "#15803d",
              }}
            >
              {title}
            </h2>

            <div
              style={{ display: "flex", alignItems: "center", gap: "1rem" }}
            >
              <button
                type="button"
                onClick={() => handleScroll("right")}
                style={{
              
                  border: "none",
                  backgroundColor: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                }}
                aria-label="Scroll right"
              >
                <img
                  src={images.ArrowRight}
                  alt="Next"
                  style={{ width: "30px", height: "30px", objectFit: "contain" }}
                />
              </button>
            </div>
          </header>

          <div
            ref={scrollContainerRef}
            style={{
              display: "flex",
              gap: "2rem",
              overflowX: "auto",
              padding: "0 0 1.5rem 0",
              scrollBehavior: "smooth",
              msOverflowStyle: "none", // IE and Edge
              scrollbarWidth: "none", // Firefox
            }}
          >
            {items.map((item) => {
              const isWishlisted = wishlistIds.has(item.id);

              return (
                <article
                  key={item.id}
                  onClick={() => navigate(`/trailer/${item.id}`)}
                  style={{
                    width: "250px",
                    minWidth: "250px",
                    maxWidth: "250px",
                    backgroundColor: "#ffffff",
                    borderRadius: "16px",
                    boxShadow: "0 10px 25px rgba(15,23,42,0.1)",
                    overflow: "hidden",
                    flexShrink: 0,
                    cursor: "pointer",
                  }}
                >
                <div
                  style={{
                    position: "relative",
                    width: "100%",
                    height: "250px",
                    overflow: "hidden",
                  }}
                >
                  <img
                    src={item.image}
                    alt={item.modelLabel}
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                      display: "block",
                    }}
                  />

                  {item.badgeLabel && (
                    <span
                      style={{
                        position: "absolute",
                        top: "0.75rem",
                        left: "0.75rem",
                        padding: "0.25rem 0.6rem",
                        borderRadius: "9999px",
                        backgroundColor: "#ffffff",
                        fontSize: "0.7rem",
                        fontFamily: fonts.medium,
                        color: "#111827",
                        boxShadow: "0 6px 12px rgba(15,23,42,0.22)",
                      }}
                    >
                      {item.badgeLabel}
                    </span>
                  )}

              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  toggleWishlist(item.id);
                }}
                style={{
                  position: "absolute",
                  top: "0.75rem",
                  right: "0.75rem",
                  width: "28px",
                  height: "28px",
                  borderRadius: "9999px",
                  border: "none",
                  backgroundColor: "rgba(255,255,255,0.9)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  padding: 0,
                  transition: "background-color 0.2s ease",
                }}
                aria-label="Save to favourites"
              >
                <img
                  src={images.Wishlist}
                  alt="Wishlist"
                  style={{
                    width: "18px",
                    height: "18px",
                    objectFit: "contain",
                    // make only the icon red when wishlisted
                    filter: isWishlisted
                      ? "invert(25%) sepia(93%) saturate(7480%) hue-rotate(357deg) brightness(99%) contrast(115%)"
                      : "none",
                  }}
                />
              </button>
                </div>

                <div
                  style={{
                    padding: "0.85rem 0.9rem 1rem",
                    display: "flex",
                    flexDirection: "column",
                    gap: "0.25rem",
                  }}
                >
                  <p
                    style={{
                      margin: 0,
                      fontFamily: fonts.bold,
                      fontSize: "0.85rem",
                      color:colors.black,
                    }}
                  >
                    {item.modelLabel}
                  </p>
                  <p
                    style={{
                      margin: 0,
                      fontFamily: fonts.regular,
                      fontSize: "0.9rem",
                      color: colors.gray,
                    }}
                  >
                    {item.priceLabel}
                  </p>
                </div>
                </article>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

