import React from "react";
import { Star } from "lucide-react";

type Review = {
  avatar: string;
  name: string;
  stars: number;
  context: string;
  text: string;
};

type ReviewsSectionProps = {
  reviews: Review[];
};

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ reviews }) => {
  const displayReviews = reviews.slice(0, 6);

  return (
    <section>
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Reviews</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {displayReviews.map((review, i) => (
          <div key={i} className="flex gap-4">
            <div className="shrink-0 w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-semibold overflow-hidden">
              {review.avatar ? (
                <img
                  src={review.avatar}
                  alt=""
                  className="w-full h-full object-cover"
                />
              ) : (
                review.name.charAt(0)
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-semibold text-sm text-gray-900">
                {review.name}
              </p>
              <p className="text-xs text-gray-500">{review.context}</p>
              <div className="flex text-black gap-0.5 my-1">
                {Array.from({ length: review.stars }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <p className="text-sm text-gray-700 leading-relaxed mt-2">
                {review.text}
              </p>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-10 flex justify-end">
        <button
          type="button"
          className="bg-[#389131] text-white px-8 py-3 rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity"
        >
          Show all reviews
        </button>
      </div>
    </section>
  );
};

