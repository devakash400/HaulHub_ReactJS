import React from "react";
import { Star } from "lucide-react";

type RatingSummaryCardProps = {
  rating: number;
  description: string;
  reviewCount: number;
};

export const RatingSummaryCard: React.FC<RatingSummaryCardProps> = ({
  rating,
  description,
  reviewCount,
}) => {
  return (
    <article className="bg-[#F6F1E8] rounded-2xl border border-gray-300 px-6 py-4 flex items-center justify-between gap-6">
      <div className="flex flex-col items-start">
        <p className="text-lg font-semibold text-gray-900">{rating}</p>
        <div className="flex text-yellow-400 mt-0.5">
          {[1, 2, 3, 4, 5].map((i) => (
            <Star key={i} className="w-4 h-4 fill-current" aria-hidden />
          ))}
        </div>
      </div>

      <p className="flex-1 text-xs sm:text-sm text-gray-700 text-center sm:text-left">
        {description}
      </p>

      <div className="text-right">
        <p className="text-lg font-semibold text-gray-900">{reviewCount}</p>
        <p className="text-xs text-gray-600">Reviews</p>
      </div>
    </article>
  );
};

