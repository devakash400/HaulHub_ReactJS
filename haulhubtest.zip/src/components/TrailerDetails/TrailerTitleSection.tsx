import React from "react";
import { Share2 } from "lucide-react";
import { images } from "../../assets/images/index.ts";

type TrailerTitleSectionProps = {
  title: string;
  location: string;
  specs: string;
};

export const TrailerTitleSection: React.FC<TrailerTitleSectionProps> = ({
  title,
}) => {
  return (
    <section className="flex flex-row flex-wrap items-start justify-between gap-4 mb-6">
      <div>
        <h1 className="text-3xl lg:text-4xl font-semibold tracking-tight text-[#389131] mb-2">
          {title}
        </h1>
      </div>
      <div className="flex items-center gap-4 shrink-0">
        <button
          type="button"
          className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:underline"
          aria-label="Share"
        >
          <Share2 className="w-4 h-4" />
          <span>Share</span>
        </button>
        <button
          type="button"
          className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:underline"
          aria-label="Save"
        >
          <img
            src={images.Wishlist}
            alt=""
            className="w-4 h-4 object-contain"
          />
          <span>Save</span>
        </button>
      </div>
    </section>
  );
};

