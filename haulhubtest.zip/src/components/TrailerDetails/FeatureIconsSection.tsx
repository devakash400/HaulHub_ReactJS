import React from "react";
import dexterityIcon from "../../assets/icons/dexterity-icon.png";
import towingIcon from "../../assets/icons/towing-service-icon.png";
import traction from "../../assets/icons/traction-control-icon.png";



type Feature = {
  icon: "commercial" | "towing" | "road";
  label: string;
};

const iconMap: Record<Feature["icon"], string> = {
  commercial: dexterityIcon,
  towing: towingIcon,
  road: traction
};

type FeatureIconsSectionProps = {
  features: Feature[];
};

export const FeatureIconsSection: React.FC<FeatureIconsSectionProps> = ({
  features,
}) => {
  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
      {features.map(({ icon, label }) => {
        const iconSrc = iconMap[icon];
        return (
          <div key={label}>
            <img
              src={iconSrc}
              alt={label}
              className="w-10 h-10 mx-auto mb-4 object-contain"
            />
            <p className="text-sm font-medium text-gray-800">{label}</p>
          </div>
        );
      })}
    </section>
  );
};

